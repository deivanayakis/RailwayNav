# leaflet-control-geocoder-demo-esbuild

This demo demonstrates the usage of leaflet-control-geocoder using the [esbuild](https://github.com/evanw/esbuild) bundler.

1. `cd demo-esbuild/`
2. `npm install`
3. `npm run build`
4. `xdg-open index.html` or open `index.html` in your browser
